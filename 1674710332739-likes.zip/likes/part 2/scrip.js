console.log("page loading...");

let count = 9;
let like1 = document.querySelector("#click");

console.log(like1);

function add1() {
    count++;
    like1.innerText = count + " like(s)" ;
    console.log(count);
}

let count2 = 12;
let like2 = document.querySelector("#click2");

console.log(count2);

function add2() {
    count2++;
    like2.innerText = count2 + " like(s)";
    console.log(count2);
}

let count3 = 9;
let like3 = document.querySelector("#click3");

console.log(like3);

function add3() {
    count3++;
    like3.innerText = count3 + " like(s)";
    console.log(count3);
}


